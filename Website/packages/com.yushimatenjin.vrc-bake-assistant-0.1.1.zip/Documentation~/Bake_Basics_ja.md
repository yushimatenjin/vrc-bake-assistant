# ライトベイク基礎整理

## Lightmap

床、壁、家具などの静的なオブジェクトに、光と影の結果をテクスチャとして焼き込む仕組みです。ランタイム中のライト計算を減らせるため、VRChatワールドでは重要です。

## Light Probe

空間中の明るさを点として保存します。アバターや動く小物など、ライトマップを持たないオブジェクトをワールドの明るさに馴染ませる用途で使います。

## Reflection Probe

指定位置から周囲をキューブマップとして記録し、金属、ガラス、水面、つるつるした床などの反射に使います。部屋ごと、屋外/屋内の境目、見た目が大きく変わる場所に置くと効果が分かりやすいです。

## Static / Contribute GI

ライトマップに焼きたいオブジェクトは `Contribute GI` を有効にします。Reflection Probeに写ってほしい静的オブジェクトは `Reflection Probe Static` も有効にします。

## UV2 / Generate Lightmap UVs

ライトマップは通常UV2を使います。FBXなどでUV2が無い場合は、Model Importerの `Generate Lightmap UVs` を有効にして再インポートします。

## おすすめワークフロー

1. シーンを保存・バックアップ
2. Practice Fastで試し焼き
3. ライトの位置・色・強さを調整
4. Light Probe / Reflection Probeを配置
5. PC BalancedやQuest Lightで本番寄りに焼く
6. VRChat SDKでビルド・実機確認

## 販売時の訴求点

- 設定場所が分散しているベイク作業を1ウィンドウにまとめる
- 初心者が迷いやすいStatic、UV2、Probe不足を診断する
- 試し焼きと本番焼きのプリセットを分け、失敗時の時間損失を減らす
- 練習シーン同梱で購入直後に学べる
